from django.urls import path
from django.contrib.auth.views import LogoutView, LoginView
from . import views

app_name = "users"

urlpatterns = [
    path("profile/", views.user, name="profile"),
    path("registration/", views.register, name="register")
]

