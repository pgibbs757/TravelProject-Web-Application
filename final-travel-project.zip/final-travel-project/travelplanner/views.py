from django.contrib.auth import user_logged_in, user_logged_out, logout, authenticate, login
from django.dispatch import receiver
from django.shortcuts import render, redirect
from .models import City, Trip, Restaurant
from .forms import RestaurantForm, ActivityForm, NightlifeForm, UserRegistrationForm
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required


# Create your views here.
def home(request):
    

    return render(request, "travelplanner/index.html")


def showCities(request):
    cities_list = City.objects.all()
    context = {'cities': cities_list}
    return render(request, "travelplanner/showCities.html", context)


@login_required
def create_trip(request, city_id):
    if request.method == 'POST':
        restaurant_form = RestaurantForm(request.POST)
        activity_form = ActivityForm(request.POST)
        nightlife_form = NightlifeForm(request.POST)

        city_id = int(city_id)  # filters it by city

        RestaurantForm.set_restaurants_queryset(restaurant_form, city_id)
        ActivityForm.set_activities_queryset(activity_form, city_id)
        NightlifeForm.set_nightlife_queryset(nightlife_form, city_id)

        
        if restaurant_form.is_bound and activity_form.is_bound and nightlife_form.is_bound:
            
            if restaurant_form.is_valid() and activity_form.is_valid() and nightlife_form.is_valid():
                # gets the data from form
                selected_restaurants = restaurant_form.cleaned_data.get('restaurants', [])
                selected_activities = activity_form.cleaned_data.get('activities', [])
                selected_nightlife = nightlife_form.cleaned_data.get('nightlife', [])

                # makes the new trip
                city = City.objects.get(id=city_id)
                new_trip = Trip.objects.create(city=city, user=request.user)

                # adds selected form options
                new_trip.restaurants.set(selected_restaurants)
                new_trip.activities.set(selected_activities)
                new_trip.nightlife.set(selected_nightlife)

                return redirect('travelplanner:my_trips')
    
    else:
        city_id = int(city_id)  
        restaurant_form = RestaurantForm()
        activity_form = ActivityForm()
        nightlife_form = NightlifeForm()

        RestaurantForm.set_restaurants_queryset(restaurant_form, city_id)
        ActivityForm.set_activities_queryset(activity_form, city_id)
        NightlifeForm.set_nightlife_queryset(nightlife_form, city_id)
        city = City.objects.get(id=city_id)
        city_name = city.name

    context = {
        'city_id': city_id,
        'city_name': city_name,
        'restaurant_form': restaurant_form,
        'activity_form': activity_form,
        'nightlife_form': nightlife_form
    }
    return render(request, "travelplanner/createTrip.html", context)


@login_required
def my_trips(request):
    # get trips associated w user
    trips = Trip.objects.filter(user=request.user).prefetch_related('restaurants', 'activities', 'nightlife')
    context = {'trips': trips}
    return render(request, "travelplanner/my_trips.html", context)


def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
           
            return redirect("travelplanner:home")
    else:
        form = UserRegistrationForm()
    return render(request, "travelplanner/registration.html", {'form': form})


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            
            return redirect('travelplanner:home')  
        else:
            
            return render(request, 'registration/login.html', {'error_message': 'Invalid username or password'})
    else:
        return render(request, 'registration/login.html')


def logout_view(request):
    logout(request)
    return redirect("travelplanner:home")


@receiver(user_logged_in)
def on_user_logged_in(sender, request, **kwargs):
    
    pass


@receiver(user_logged_out)
def on_user_logged_out(sender, request, user, **kwargs):
    
    pass
