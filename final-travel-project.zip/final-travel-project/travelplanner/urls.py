"""
URL configuration for finalproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.urls import path
from . import views
import users.views

app_name = "travelplanner"

urlpatterns = [
    path("", views.home, name="home"),
    path("showCities.html/", views.showCities, name="showCities"),
    path("showCities/<int:city_id>/", views.create_trip, name="city_plans"),
    path('create_trip/<int:city_id>/', views.create_trip, name='create_trip'),
    path("my_trips/", views.my_trips, name="my_trips"),
    path("registration/", views.register, name="registration"),
    path("users/templates/registration/login", views.login_view, name="login"),
    path("users/templates/profile", users.views.user, name="profile"),
    path("users/templates/registration/logout", views.logout_view, name="logout"),
] 