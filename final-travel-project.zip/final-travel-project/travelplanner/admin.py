from django.contrib import admin

# Register your models here.
from .models import City, Restaurant, Activity, Nightlife

admin.site.register(City)

admin.site.register(Restaurant)

admin.site.register(Activity)

admin.site.register(Nightlife)