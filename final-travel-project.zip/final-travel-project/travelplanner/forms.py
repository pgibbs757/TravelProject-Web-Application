from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from .models import Restaurant, Activity, Nightlife


class RestaurantForm(forms.Form):
    restaurants = forms.ModelMultipleChoiceField(queryset=Restaurant.objects.none(),
                                                 widget=forms.CheckboxSelectMultiple, required=False)

    def set_restaurants_queryset(form, city_id):
        queryset = Restaurant.objects.filter(city_id=city_id)
        form.fields['restaurants'].queryset = queryset


class ActivityForm(forms.Form):
    activities = forms.ModelMultipleChoiceField(queryset=Activity.objects.none(), widget=forms.CheckboxSelectMultiple,
                                                required=False)

    def set_activities_queryset(form, city_id):
        queryset = Activity.objects.filter(city_id=city_id)
        form.fields['activities'].queryset = queryset


class NightlifeForm(forms.Form):
    nightlife = forms.ModelMultipleChoiceField(queryset=Nightlife.objects.none(), widget=forms.CheckboxSelectMultiple,
                                               required=False)

    def set_nightlife_queryset(form, city_id):
        queryset = Nightlife.objects.filter(city_id=city_id)
        form.fields['nightlife'].queryset = queryset


class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField()
    phonenumber = forms.IntegerField()

    class Meta:
        model = User
        fields = ['username', 'email', 'phonenumber', 'password1', 'password2']
