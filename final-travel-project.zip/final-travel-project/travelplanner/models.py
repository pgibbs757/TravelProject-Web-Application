from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class City(models.Model):
    name = models.CharField(max_length=30);
    def __str__(self):
        return self.name
    

class Restaurant(models.Model):
    name = models.CharField(max_length=30);
    address = models.CharField(max_length=30);
    price_point = models.CharField(max_length=30);
    rating = models.CharField(max_length=30);
    city = models.ForeignKey(City, on_delete=models.CASCADE)
    
    def __str__(self):
       return f'{self.name}. Located at {self.address}. Price can be around {self.price_point}. Rated at {self.rating}'


class Activity(models.Model):
    name = models.CharField(max_length=30);
    location = models.CharField(max_length=30);
    price = models.CharField(max_length=30);
    rating = models.CharField(max_length=30);
    city = models.ForeignKey(City, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.name}. Located at {self.location}. Price can be around {self.price}. Rated at {self.rating}'


class Nightlife(models.Model):
    name = models.CharField(max_length=30);
    address = models.CharField(max_length=30);
    price_point = models.CharField(max_length=30);
    rating = models.CharField(max_length=30);
    city = models.ForeignKey(City, on_delete=models.CASCADE)

    def __str__(self):
        return f'{self.name}. Located at {self.address}. Price can be around {self.price_point}. Rated at {self.rating}'
    

class Trip(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    city = models.ForeignKey(City, on_delete=models.CASCADE)
    restaurants = models.ManyToManyField(Restaurant)
    activities = models.ManyToManyField(Activity)
    nightlife = models.ManyToManyField(Nightlife)
    
    def __str__(self):
        return f'Trip to {self.city.name}'